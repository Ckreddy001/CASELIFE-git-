# CASEFILE: An AI-Powered Missing Person Investigation and Probable Location Prediction System Using Advanced Machine Learning

> **Academic simulation only.** This project uses fictional case data and synthetic movement data. It is not intended for real-world missing-person investigations or operational decisions.

## Features
- GPS movement preprocessing and feature engineering
- K-Means movement clustering
- Isolation Forest anomaly detection
- Random Forest probable-area prediction
- Markov Chain route prediction
- Search-priority scoring
- Feature-importance explanations
- Folium interactive map
- Streamlit dashboard

## Workflow
DATA COLLECTION → DATA CLEANING → FEATURE ENGINEERING → EDA → MOVEMENT CLUSTERING → ANOMALY DETECTION → LOCATION PREDICTION → ROUTE PREDICTION → SEARCH PRIORITY SCORE → EXPLAINABLE AI → INTERACTIVE MAP → STREAMLIT DASHBOARD

## Quick start (macOS)
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python src/generate_synthetic_data.py
python src/train_pipeline.py
streamlit run app/app.py
```

The generated fictional case is `MP-2026-017`.

## Data
The project is designed around public GPS trajectory data such as the Microsoft GeoLife GPS Trajectory Dataset plus synthetic case information. Do not add private or personally identifiable missing-person records.

## Important limitations
Model outputs are probabilistic rankings, not proof of a person's location. An anomaly is not evidence of criminal or suspicious behavior. False positives, dataset bias, sparse observations, and geographic sampling limitations must be considered.

## Project structure
- `data/raw` - public/raw datasets
- `data/processed` - cleaned/engineered data
- `data/synthetic` - fictional case and generated movement data
- `src` - reusable Python modules
- `models` - trained models and preprocessing objects
- `app` - Streamlit dashboard
- `docs` - dataset documentation
- `reports` - report/presentation outputs
