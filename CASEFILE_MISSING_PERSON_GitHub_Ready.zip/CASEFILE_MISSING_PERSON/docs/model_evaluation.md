# Model Evaluation Plan

## Location prediction
Compare at least two suitable classifiers, for example:
- Random Forest
- Gradient Boosting / XGBoost

Report:
- Accuracy
- Precision
- Recall
- F1
- Confusion matrix
- Top-1, Top-3 and Top-5 accuracy where applicable

## Anomaly detection
Report:
- Number/percentage of anomalies
- Threshold/contamination choice
- False-positive/false-negative discussion
- Limitations of unsupervised anomaly labels

## Route prediction
Use a Markov Chain / transition-probability approach as required by the project.
