# Ethics and Limitations

1. All identities in this project are fictional.
2. Do not use private missing-person records or PII.
3. Predictions are probabilistic and must never be presented as proof.
4. An anomaly is not automatically suspicious or criminal behavior.
5. Search-priority scores are simulated academic outputs, not operational instructions.
6. Dataset bias, sparse GPS observations, location uncertainty and false positives must be documented.
