# Dataset Source Document

## 1. Public movement dataset
**Name:** Microsoft GeoLife GPS Trajectory Dataset  
**Source:** Microsoft Research  
**Purpose:** Historical GPS trajectory analysis and movement-pattern experimentation.  
**Use in this project:** Demonstrates trajectory preprocessing, movement statistics, clustering, and anomaly analysis.

## 2. Geographic/contextual data
OpenStreetMap can be used for roads, intersections, railway stations, bus stops, hospitals, markets, schools, parks and residential areas.

## 3. Synthetic case data
The project creates fictional case information locally. No real missing-person identity is used.

### Synthetic case fields
- Case_ID
- Person_ID
- Age_Group
- Gender
- Last_Latitude
- Last_Longitude
- Last_Seen_Time
- Day
- Weather
- Usual_Area
- Average_Distance
- Average_Speed
- Previous_Area
- Time_Since_Last_Seen
- Target_Area

## Ethics
Only fictional/synthetic case information should be used. Never upload private records, names, phone numbers, photographs, addresses, or other personally identifiable information.
