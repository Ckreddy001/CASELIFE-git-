from pathlib import Path
import sys
import joblib
import pandas as pd
import streamlit as st
import folium
from streamlit_folium import st_folium

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / "src"))

from prediction import predict_case
from mapping import make_map
from priority_scoring import search_priority, band

st.set_page_config(page_title="CASEFILE Dashboard", layout="wide")
st.title("CASEFILE — AI Investigation Support Dashboard")
st.caption("Academic simulation using fictional/synthetic data. Not for real-world missing-person decisions.")

data = ROOT / "data" / "synthetic"
models = ROOT / "models"

case = pd.read_csv(data / "synthetic_case.csv").iloc[0]
movement = pd.read_csv(ROOT / "data" / "processed" / "anomaly_results.csv")
location_model, label_encoder = joblib.load(models / "location_model.pkl")
route_model = joblib.load(models / "markov_route_model.pkl")

st.subheader(f"Case: {case['Case_ID']}")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Age Group", case["Age_Group"])
c2.metric("Last Seen", case["Last_Seen_Time"])
c3.metric("Weather", case["Weather"])
c4.metric("Usual Area", case["Usual_Area"])

case_row = {
    "Hour": pd.to_datetime(case["Last_Seen_Time"]).hour,
    "Last_Latitude": case["Last_Latitude"],
    "Last_Longitude": case["Last_Longitude"],
    "Average_Distance": case["Average_Distance"],
    "Average_Speed": case["Average_Speed"],
    "Time_Since_Last_Seen": case["Time_Since_Last_Seen"],
}
pred = predict_case(location_model, label_encoder, case_row)

# Frequency normalized by area.
freq = movement["Area"].value_counts(normalize=True).to_dict()
route = route_model.predict_route(case["Previous_Area"], steps=4)

pred["Visit_Frequency"] = pred["Area"].map(freq).fillna(0)
pred["Visit_Frequency"] = pred["Visit_Frequency"] / max(pred["Visit_Frequency"].max(), 1e-9)
pred["Route_Similarity"] = pred["Area"].apply(lambda x: 1.0 if x in route else 0.2)
pred["Distance_Relevance"] = 1.0
pred["Time_Relevance"] = 1.0
pred["Anomaly_Evidence"] = 0.5
pred["Priority_Score"] = pred.apply(lambda r: search_priority(
    r["Probability"], r["Visit_Frequency"], r["Route_Similarity"],
    r["Distance_Relevance"], r["Time_Relevance"], r["Anomaly_Evidence"]
), axis=1)
pred["Priority"] = pred["Priority_Score"].apply(band)

st.subheader("Top probable areas")
st.dataframe(pred[["Area","Probability_Percent","Priority_Score","Priority"]], use_container_width=True)

st.subheader("Probable route (Markov Chain)")
st.write(" → ".join(route))

st.subheader("Movement anomalies")
st.metric("Detected synthetic anomalies", int(movement["Anomaly"].sum()))

st.subheader("Interactive map")
area_coords = {
    "Central": (23.2599, 77.4126),
    "North": (23.2850, 77.4050),
    "East": (23.2650, 77.4550),
    "South": (23.2200, 77.4300),
    "West": (23.2500, 77.3650),
    "Park": (23.2750, 77.4300),
}
m = make_map(case["Last_Latitude"], case["Last_Longitude"], pred, area_coords, route)
st_folium(m, width=1100, height=600)

st.subheader("Model explanation")
st.write(
    "The Random Forest model ranks geographic areas from historical movement features. "
    "The ranking is probabilistic. In a full report, feature importance/SHAP can be used "
    "to explain which features contributed most to each prediction."
)

st.warning(
    "Ethics: an anomaly does not automatically mean suspicious or criminal behavior, "
    "and a model prediction does not prove a person's location."
)
