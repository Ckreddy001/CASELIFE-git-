from collections import defaultdict, Counter

class MarkovRouteModel:
    def __init__(self):
        self.transitions = defaultdict(Counter)

    def fit(self, df):
        for uid, g in df.sort_values("Timestamp").groupby("User_ID"):
            areas = g["Area"].astype(str).tolist()
            for a, b in zip(areas, areas[1:]):
                self.transitions[a][b] += 1
        return self

    def next_probabilities(self, current_area):
        counts = self.transitions.get(current_area, {})
        total = sum(counts.values())
        if not total:
            return {}
        return {k: round(v/total, 4) for k,v in counts.items()}

    def predict_route(self, start_area, steps=4):
        route = [start_area]
        current = start_area
        for _ in range(steps):
            probs = self.next_probabilities(current)
            if not probs:
                break
            current = max(probs, key=probs.get)
            route.append(current)
        return route
