from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "synthetic"
OUT.mkdir(parents=True, exist_ok=True)

rng = np.random.default_rng(42)

# Fictional city-like coordinate space for academic simulation.
areas = {
    "Central": (23.2599, 77.4126),
    "North": (23.2850, 77.4050),
    "East": (23.2650, 77.4550),
    "South": (23.2200, 77.4300),
    "West": (23.2500, 77.3650),
    "Park": (23.2750, 77.4300),
}

rows = []
users = range(1, 31)
start = pd.Timestamp("2026-01-01")

for uid in users:
    home = rng.choice(list(areas))
    for i in range(220):
        day = start + pd.Timedelta(days=int(i))
        hour = int(rng.choice([7, 8, 9, 13, 17, 18, 19, 20], p=[.08,.12,.08,.10,.15,.18,.17,.12]))
        minute = int(rng.integers(0, 60))
        ts = day + pd.Timedelta(hours=hour, minutes=minute)
        if rng.random() < 0.72:
            area = home
        else:
            area = rng.choice(list(areas), p=[.25,.12,.15,.15,.15,.18])
        lat0, lon0 = areas[area]
        lat = lat0 + rng.normal(0, 0.004)
        lon = lon0 + rng.normal(0, 0.004)
        rows.append([uid, lat, lon, ts, area])

movement = pd.DataFrame(rows, columns=["User_ID","Latitude","Longitude","Timestamp","Area"])
movement["Date"] = movement["Timestamp"].dt.date
movement["Hour"] = movement["Timestamp"].dt.hour
movement["Day"] = movement["Timestamp"].dt.day_name()
movement["Weather"] = rng.choice(["Clear","Cloudy","Rain"], len(movement), p=[.55,.30,.15])

# Add a small number of synthetic unusual points.
idx = rng.choice(movement.index, 40, replace=False)
movement.loc[idx, "Latitude"] += rng.normal(0.03, 0.008, len(idx))
movement.loc[idx, "Longitude"] += rng.normal(0.03, 0.008, len(idx))
movement.to_csv(OUT / "synthetic_movement.csv", index=False)

case = pd.DataFrame([{
    "Case_ID": "MP-2026-017",
    "Person_ID": "SYNTH-001",
    "Age_Group": "18-25",
    "Gender": "Not specified",
    "Last_Latitude": 23.2599,
    "Last_Longitude": 77.4126,
    "Last_Seen_Time": "2026-09-04 18:45",
    "Day": "Friday",
    "Weather": "Rain",
    "Usual_Area": "Central",
    "Average_Distance": 10.0,
    "Average_Speed": 4.5,
    "Previous_Area": "East",
    "Time_Since_Last_Seen": 2.0,
    "Target_Area": "Central"
}])
case.to_csv(OUT / "synthetic_case.csv", index=False)
print("Created synthetic movement and fictional case datasets.")
