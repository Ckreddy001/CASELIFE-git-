from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

FEATURES = ["Distance_km","Speed_kmh","Hour"]

def fit_anomaly_model(df):
    X = df[FEATURES].fillna(0)
    scaler = StandardScaler()
    xs = scaler.fit_transform(X)
    model = IsolationForest(
        n_estimators=200,
        contamination=0.08,
        random_state=42
    )
    pred = model.fit_predict(xs)
    out = df.copy()
    out["Anomaly"] = (pred == -1).astype(int)
    out["Anomaly_Score"] = -model.decision_function(xs)
    return model, scaler, out
