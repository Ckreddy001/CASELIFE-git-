from pathlib import Path
import joblib
import pandas as pd

from preprocessing import clean_and_engineer
from clustering import cluster_locations
from anomaly_detection import fit_anomaly_model
from prediction import train_location_model
from route_prediction import MarkovRouteModel

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "synthetic"
MODELS = ROOT / "models"
MODELS.mkdir(exist_ok=True)

df = pd.read_csv(DATA / "synthetic_movement.csv")
df = clean_and_engineer(df)
df.to_csv(ROOT / "data" / "processed" / "movement_features.csv", index=False)

cluster_model, cluster_scaler, clustered = cluster_locations(df)
clustered.to_csv(ROOT / "data" / "processed" / "clustered_movement.csv", index=False)
joblib.dump((cluster_model, cluster_scaler), MODELS / "clustering_model.pkl")

anomaly_model, anomaly_scaler, anomalous = fit_anomaly_model(clustered)
anomalous.to_csv(ROOT / "data" / "processed" / "anomaly_results.csv", index=False)
joblib.dump((anomaly_model, anomaly_scaler), MODELS / "anomaly_model.pkl")

location_model, label_encoder, train_data = train_location_model(anomalous)
joblib.dump((location_model, label_encoder), MODELS / "location_model.pkl")

route_model = MarkovRouteModel().fit(anomalous)
joblib.dump(route_model, MODELS / "markov_route_model.pkl")

print("Training complete. Models saved in models/.")
