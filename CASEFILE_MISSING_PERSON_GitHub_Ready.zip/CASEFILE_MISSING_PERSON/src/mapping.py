import folium

def make_map(case_lat, case_lon, predictions, area_coords, route=None):
    m = folium.Map(location=[case_lat, case_lon], zoom_start=12)
    folium.Marker(
        [case_lat, case_lon],
        tooltip="Last known location (fictional case)"
    ).add_to(m)

    for _, row in predictions.iterrows():
        area = row["Area"]
        if area not in area_coords:
            continue
        lat, lon = area_coords[area]
        folium.CircleMarker(
            [lat, lon],
            radius=8,
            tooltip=f"{area}: {row['Probability_Percent']:.2f}%"
        ).add_to(m)

    if route:
        coords = [area_coords[a] for a in route if a in area_coords]
        if len(coords) >= 2:
            folium.PolyLine(coords, tooltip="Predicted Markov route").add_to(m)
    return m
