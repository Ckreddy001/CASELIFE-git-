def search_priority(prediction_probability, visit_frequency,
                     route_similarity, distance_relevance,
                     time_relevance, anomaly_evidence):
    # Weights follow the project guideline's suggested weighting.
    score = (
        30 * prediction_probability +
        20 * visit_frequency +
        15 * route_similarity +
        15 * distance_relevance +
        10 * time_relevance +
        10 * anomaly_evidence
    )
    return round(float(max(0, min(100, score))), 2)

def band(score):
    if score <= 30:
        return "Low"
    if score <= 60:
        return "Medium"
    if score <= 80:
        return "High"
    return "Very High"
