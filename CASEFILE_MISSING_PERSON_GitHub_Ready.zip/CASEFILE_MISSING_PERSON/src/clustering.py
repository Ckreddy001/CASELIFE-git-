from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler

def cluster_locations(df, n_clusters=6):
    X = df[["Latitude","Longitude"]].copy()
    scaler = StandardScaler()
    xs = scaler.fit_transform(X)
    model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = model.fit_predict(xs)
    out = df.copy()
    out["Cluster"] = labels
    return model, scaler, out

def dbscan_locations(df, eps=0.25, min_samples=8):
    scaler = StandardScaler()
    xs = scaler.fit_transform(df[["Latitude","Longitude"]])
    model = DBSCAN(eps=eps, min_samples=min_samples)
    return model.fit_predict(xs)
