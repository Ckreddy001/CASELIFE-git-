import numpy as np
import pandas as pd

def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dphi = np.radians(lat2-lat1)
    dlambda = np.radians(lon2-lon1)
    a = np.sin(dphi/2)**2 + np.cos(p1)*np.cos(p2)*np.sin(dlambda/2)**2
    return 2*r*np.arcsin(np.sqrt(a))

def clean_and_engineer(df):
    df = df.copy()
    df["Timestamp"] = pd.to_datetime(df["Timestamp"], errors="coerce")
    df["Latitude"] = pd.to_numeric(df["Latitude"], errors="coerce")
    df["Longitude"] = pd.to_numeric(df["Longitude"], errors="coerce")
    df = df.dropna(subset=["Timestamp","Latitude","Longitude","User_ID"])
    df = df[(df["Latitude"].between(-90,90)) & (df["Longitude"].between(-180,180))]
    df = df.drop_duplicates().sort_values(["User_ID","Timestamp"])

    g = df.groupby("User_ID", group_keys=False)
    df["Prev_Latitude"] = g["Latitude"].shift()
    df["Prev_Longitude"] = g["Longitude"].shift()
    df["Prev_Timestamp"] = g["Timestamp"].shift()

    df["Distance_km"] = haversine_km(
        df["Prev_Latitude"].fillna(df["Latitude"]),
        df["Prev_Longitude"].fillna(df["Longitude"]),
        df["Latitude"], df["Longitude"]
    )
    df["Time_Diff_h"] = (df["Timestamp"] - df["Prev_Timestamp"]).dt.total_seconds().div(3600).fillna(0)
    df["Speed_kmh"] = np.where(df["Time_Diff_h"] > 0, df["Distance_km"]/df["Time_Diff_h"], 0)
    df["Hour"] = df["Timestamp"].dt.hour
    df["Weekday"] = df["Timestamp"].dt.day_name()
    df["Is_Weekend"] = df["Timestamp"].dt.dayofweek >= 5
    df["Month"] = df["Timestamp"].dt.month
    return df
