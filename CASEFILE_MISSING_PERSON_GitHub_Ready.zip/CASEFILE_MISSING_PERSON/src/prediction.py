import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

FEATURES = [
    "Hour","Last_Latitude","Last_Longitude",
    "Average_Distance","Average_Speed",
    "Time_Since_Last_Seen"
]

def build_location_training_data(df):
    # One training record per movement observation.
    x = df.copy()
    x["Last_Latitude"] = x["Latitude"]
    x["Last_Longitude"] = x["Longitude"]
    x["Average_Distance"] = x.groupby("User_ID")["Distance_km"].transform("mean")
    x["Average_Speed"] = x.groupby("User_ID")["Speed_kmh"].transform("mean").clip(0, 150)
    x["Time_Since_Last_Seen"] = 0.0
    return x.dropna(subset=FEATURES + ["Area"])

def train_location_model(df):
    data = build_location_training_data(df)
    X = data[FEATURES].fillna(0)
    le = LabelEncoder()
    y = le.fit_transform(data["Area"].astype(str))
    model = RandomForestClassifier(
        n_estimators=250, max_depth=12, random_state=42, class_weight="balanced"
    )
    model.fit(X, y)
    return model, le, data

def predict_case(model, label_encoder, case_row):
    X = pd.DataFrame([case_row])[FEATURES].fillna(0)
    probs = model.predict_proba(X)[0]
    result = pd.DataFrame({
        "Area": label_encoder.inverse_transform(model.classes_),
        "Probability": probs
    }).sort_values("Probability", ascending=False).reset_index(drop=True)
    result["Probability_Percent"] = (result["Probability"]*100).round(2)
    return result
