Create the seven notebooks required by the guideline:
01_data_collection.ipynb
02_data_preprocessing.ipynb
03_eda.ipynb
04_clustering.ipynb
05_anomaly_detection.ipynb
06_location_prediction.ipynb
07_route_prediction.ipynb

The reusable logic is already implemented in src/. Each notebook should document the
student's independent analysis, experiments, plots, metrics and model comparisons.
